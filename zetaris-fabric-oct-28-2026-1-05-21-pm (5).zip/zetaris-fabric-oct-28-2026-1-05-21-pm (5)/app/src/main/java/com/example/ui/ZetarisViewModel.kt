package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ZetarisRepository
import com.example.model.DataSourceInfo
import com.example.model.QueryPlan
import com.example.model.QueryType
import com.example.model.SimulationResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class PlannerUiState(
    val promptInput: String = "Find all failed starlink deliveries in postgres_orders joined with snowflake_inventory",
    val isGenerating: Boolean = false,
    val currentPlan: QueryPlan? = null,
    val isSimulating: Boolean = false,
    val simulationResult: SimulationResult? = null,
    val errorMessage: String? = null,
    val selectedTab: Int = 0,
    val historyFilter: QueryType? = null,
    val isSaved: Boolean = false
)

class ZetarisViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ZetarisRepository()

    private val _uiState = MutableStateFlow(PlannerUiState())
    val uiState: StateFlow<PlannerUiState> = _uiState.asStateFlow()

    val savedPlans: StateFlow<List<QueryPlan>> = repository.savedPlans
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val dataSources: List<DataSourceInfo> = repository.getFabricDataSources()

    init {
        // Load the initial plan on first launch
        generatePlan(_uiState.value.promptInput)
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.value = _uiState.value.copy(
            promptInput = newPrompt,
            errorMessage = null
        )
    }

    fun setSelectedTab(tab: Int) {
        _uiState.value = _uiState.value.copy(selectedTab = tab)
    }

    fun setHistoryFilter(filter: QueryType?) {
        _uiState.value = _uiState.value.copy(historyFilter = filter)
    }

    fun generatePlan(customPrompt: String? = null) {
        val prompt = customPrompt ?: _uiState.value.promptInput
        if (prompt.isBlank()) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isGenerating = true,
                errorMessage = null,
                promptInput = prompt
            )

            try {
                val plan = repository.parseNaturalLanguageQuery(prompt)
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    currentPlan = plan,
                    isSaved = false,
                    simulationResult = null
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    errorMessage = e.localizedMessage ?: "Failed to orchestrate federated plan"
                )
            }
        }
    }

    fun saveCurrentPlan() {
        val plan = _uiState.value.currentPlan ?: return
        repository.saveQueryPlan(plan)
        _uiState.value = _uiState.value.copy(isSaved = true)
    }

    fun deleteSavedPlan(planId: String) {
        repository.deleteQueryPlan(planId)
    }

    fun selectSavedPlan(plan: QueryPlan) {
        _uiState.value = _uiState.value.copy(
            currentPlan = plan,
            promptInput = plan.userPrompt,
            selectedTab = 0,
            isSaved = true,
            simulationResult = null
        )
    }

    fun runSimulation() {
        val plan = _uiState.value.currentPlan ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSimulating = true)
            delay(500) // Brief simulation calculation delay for realistic feedback
            val result = repository.simulateExecution(plan)
            _uiState.value = _uiState.value.copy(
                isSimulating = false,
                simulationResult = result
            )
        }
    }

    fun dismissSimulation() {
        _uiState.value = _uiState.value.copy(simulationResult = null)
    }

    fun getPlanJson(plan: QueryPlan): String {
        val obj = JSONObject()
        val tables = JSONArray()
        plan.targetTables.forEach { tables.put(it) }
        obj.put("targetTables", tables)
        obj.put("queryType", plan.queryType.name)

        val filters = JSONArray()
        plan.filters.forEach { f ->
            val fo = JSONObject()
            fo.put("field", f.field)
            fo.put("operator", f.operator)
            fo.put("value", f.value)
            filters.put(fo)
        }
        obj.put("filters", filters)
        obj.put("explanation", plan.explanation)
        return obj.toString(2)
    }
}
