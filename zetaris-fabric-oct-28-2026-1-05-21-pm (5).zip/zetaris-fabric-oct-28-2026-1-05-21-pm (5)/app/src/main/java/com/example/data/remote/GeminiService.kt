package com.example.data.remote

import android.util.Log
import com.example.model.QueryFilter
import com.example.model.QueryPlan
import com.example.model.QueryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService(
    private val apiKey: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun parseNaturalLanguageQuery(userPrompt: String): QueryPlan {
        return withContext(Dispatchers.IO) {
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                Log.w("GeminiService", "GEMINI_API_KEY is not configured. Using high-fidelity Zetaris semantic orchestrator.")
                return@withContext FallbackSemanticEngine.parse(userPrompt)
            }

            try {
                val requestJson = buildGeminiRequestJson(userPrompt)
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = requestJson.toString().toRequestBody(mediaType)

                // Try gemini-2.5-flash as specified by user, with fallback to gemini-1.5-flash / gemini-2.0-flash if needed
                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    Log.e("GeminiService", "Gemini API error ${response.code}: $responseBody")
                    // Fall back gracefully so user experience is uninterrupted
                    return@withContext FallbackSemanticEngine.parse(userPrompt)
                }

                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return@withContext FallbackSemanticEngine.parse(userPrompt)
                }

                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.getJSONObject(0)?.optString("text").orEmpty()

                if (text.isBlank()) {
                    return@withContext FallbackSemanticEngine.parse(userPrompt)
                }

                parseStructuredQueryPlan(userPrompt, text)
            } catch (e: Exception) {
                Log.e("GeminiService", "Error calling Gemini API, falling back to local orchestrator", e)
                FallbackSemanticEngine.parse(userPrompt)
            }
        }
    }

    private fun buildGeminiRequestJson(prompt: String): JSONObject {
        val root = JSONObject()

        // System Instruction
        val sysInstruction = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", "You are an expert SpaceXSI coding agent orchestrating federated data queries across distributed databases via Zetaris. Translate user intent into precise data operations."))
        sysInstruction.put("parts", sysParts)
        root.put("systemInstruction", sysInstruction)

        // Contents
        val contentsArray = JSONArray()
        val contentObj = JSONObject()
        val contentParts = JSONArray()
        contentParts.put(JSONObject().put("text", "Convert this user question into a federated query plan for the Zetaris data fabric: \"$prompt\""))
        contentObj.put("parts", contentParts)
        contentsArray.put(contentObj)
        root.put("contents", contentsArray)

        // Generation Config with Response Schema matching user's spec
        val genConfig = JSONObject()
        genConfig.put("responseMimeType", "application/json")

        val schema = JSONObject()
        schema.put("type", "OBJECT")

        val properties = JSONObject()

        // targetTables
        val targetTablesSchema = JSONObject()
        targetTablesSchema.put("type", "ARRAY")
        targetTablesSchema.put("items", JSONObject().put("type", "STRING"))
        targetTablesSchema.put("description", "List of distributed data sources or tables to query (e.g., snowflake_inventory, postgres_orders, aws_s3_logs)")
        properties.put("targetTables", targetTablesSchema)

        // queryType
        val queryTypeSchema = JSONObject()
        queryTypeSchema.put("type", "STRING")
        val enumVals = JSONArray().apply {
            put("SELECT")
            put("AGGREGATE")
            put("JOIN")
            put("AUDIT")
        }
        queryTypeSchema.put("enum", enumVals)
        queryTypeSchema.put("description", "The primary operation type needed")
        properties.put("queryType", queryTypeSchema)

        // filters
        val filtersSchema = JSONObject()
        filtersSchema.put("type", "ARRAY")
        val filterItemSchema = JSONObject().apply {
            put("type", "OBJECT")
            val filterProps = JSONObject().apply {
                put("field", JSONObject().put("type", "STRING"))
                put("operator", JSONObject().put("type", "STRING").put("description", "e.g., EQUALS, GREATER_THAN, CONTAINS"))
                put("value", JSONObject().put("type", "STRING"))
            }
            put("properties", filterProps)
            put("required", JSONArray().apply {
                put("field")
                put("operator")
                put("value")
            })
        }
        filtersSchema.put("items", filterItemSchema)
        filtersSchema.put("description", "Extracted filter conditions from the user prompt")
        properties.put("filters", filtersSchema)

        // explanation
        val explanationSchema = JSONObject()
        explanationSchema.put("type", "STRING")
        explanationSchema.put("description", "Step-by-step agent reasoning on how Zetaris will fetch this across sources without data movement.")
        properties.put("explanation", explanationSchema)

        schema.put("properties", properties)
        schema.put("required", JSONArray().apply {
            put("targetTables")
            put("queryType")
            put("filters")
            put("explanation")
        })

        genConfig.put("responseSchema", schema)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun parseStructuredQueryPlan(userPrompt: String, jsonString: String): QueryPlan {
        val cleanJson = jsonString.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(cleanJson)

        val targetTables = mutableListOf<String>()
        val tablesArray = json.optJSONArray("targetTables")
        if (tablesArray != null) {
            for (i in 0 until tablesArray.length()) {
                targetTables.add(tablesArray.getString(i))
            }
        }
        if (targetTables.isEmpty()) {
            targetTables.add("postgres_orders")
        }

        val qTypeStr = json.optString("queryType", "SELECT").uppercase()
        val queryType = try {
            QueryType.valueOf(qTypeStr)
        } catch (_: Exception) {
            QueryType.SELECT
        }

        val filters = mutableListOf<QueryFilter>()
        val filtersArray = json.optJSONArray("filters")
        if (filtersArray != null) {
            for (i in 0 until filtersArray.length()) {
                val fObj = filtersArray.getJSONObject(i)
                filters.add(
                    QueryFilter(
                        field = fObj.optString("field", "status"),
                        operator = fObj.optString("operator", "EQUALS"),
                        value = fObj.optString("value", "")
                    )
                )
            }
        }

        val explanation = json.optString("explanation", "Executed through Zetaris federated engine without central data migration.")

        return FallbackSemanticEngine.enrichPlan(
            rawPlan = QueryPlan(
                userPrompt = userPrompt,
                targetTables = targetTables,
                queryType = queryType,
                filters = filters,
                explanation = explanation
            )
        )
    }
}
