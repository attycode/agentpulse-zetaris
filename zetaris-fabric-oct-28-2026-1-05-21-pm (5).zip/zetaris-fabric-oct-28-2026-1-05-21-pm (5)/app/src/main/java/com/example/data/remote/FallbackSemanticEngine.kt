package com.example.data.remote

import com.example.model.QueryFilter
import com.example.model.QueryPlan
import com.example.model.QueryType
import com.example.model.SimulationResult
import java.util.Locale

object FallbackSemanticEngine {

    private val KNOWN_SOURCES = listOf(
        "snowflake_inventory",
        "postgres_orders",
        "aws_s3_logs",
        "databricks_manifests",
        "starlink_telemetry",
        "enterprise_billing"
    )

    fun parse(userPrompt: String): QueryPlan {
        val lowerPrompt = userPrompt.lowercase(Locale.ROOT)

        // 1. Detect target tables
        val matchedTables = mutableListOf<String>()
        for (source in KNOWN_SOURCES) {
            val simpleName = source.replace("_", " ")
            val shortName = source.substringAfter("_")
            if (lowerPrompt.contains(source) || lowerPrompt.contains(simpleName) || lowerPrompt.contains(shortName)) {
                matchedTables.add(source)
            }
        }

        // Contextual table matching if not explicitly named
        if (matchedTables.isEmpty()) {
            if (lowerPrompt.contains("inventory") || lowerPrompt.contains("stock") || lowerPrompt.contains("parts") || lowerPrompt.contains("warehouse")) {
                matchedTables.add("snowflake_inventory")
            }
            if (lowerPrompt.contains("order") || lowerPrompt.contains("delivery") || lowerPrompt.contains("shipping") || lowerPrompt.contains("customer")) {
                matchedTables.add("postgres_orders")
            }
            if (lowerPrompt.contains("log") || lowerPrompt.contains("audit") || lowerPrompt.contains("access") || lowerPrompt.contains("security") || lowerPrompt.contains("s3")) {
                matchedTables.add("aws_s3_logs")
            }
            if (lowerPrompt.contains("manifest") || lowerPrompt.contains("payload") || lowerPrompt.contains("cargo") || lowerPrompt.contains("databricks")) {
                matchedTables.add("databricks_manifests")
            }
            if (lowerPrompt.contains("telemetry") || lowerPrompt.contains("starlink") || lowerPrompt.contains("ping") || lowerPrompt.contains("satellite")) {
                matchedTables.add("starlink_telemetry")
            }
            if (lowerPrompt.contains("revenue") || lowerPrompt.contains("billing") || lowerPrompt.contains("cost") || lowerPrompt.contains("invoice")) {
                matchedTables.add("enterprise_billing")
            }
        }

        if (matchedTables.isEmpty()) {
            matchedTables.add("postgres_orders")
            matchedTables.add("snowflake_inventory")
        }

        // 2. Detect query type
        val queryType: QueryType = when {
            lowerPrompt.contains("audit") || lowerPrompt.contains("unauthorized") || lowerPrompt.contains("compliance") || lowerPrompt.contains("violation") -> {
                QueryType.AUDIT
            }
            lowerPrompt.contains("aggregate") || lowerPrompt.contains("calculate") || lowerPrompt.contains("total") || lowerPrompt.contains("sum") || lowerPrompt.contains("count") || lowerPrompt.contains("average") -> {
                QueryType.AGGREGATE
            }
            lowerPrompt.contains("join") || lowerPrompt.contains("with") || matchedTables.size > 1 -> {
                QueryType.JOIN
            }
            else -> {
                QueryType.SELECT
            }
        }

        // 3. Extract filters
        val filters = mutableListOf<QueryFilter>()

        // Check for status filters
        when {
            lowerPrompt.contains("failed") -> filters.add(QueryFilter("delivery_status", "EQUALS", "FAILED"))
            lowerPrompt.contains("pending") -> filters.add(QueryFilter("status", "EQUALS", "PENDING"))
            lowerPrompt.contains("delivered") -> filters.add(QueryFilter("delivery_status", "EQUALS", "DELIVERED"))
            lowerPrompt.contains("active") -> filters.add(QueryFilter("is_active", "EQUALS", "TRUE"))
            lowerPrompt.contains("unauthorized") -> filters.add(QueryFilter("action_status", "EQUALS", "UNAUTHORIZED"))
        }

        // Check for numeric / threshold filters
        val gtRegex = Regex("""(?:>|greater than|above|exceeding)\s*([0-9.]+)""", RegexOption.IGNORE_CASE)
        val gtMatch = gtRegex.find(lowerPrompt)
        if (gtMatch != null) {
            val value = gtMatch.groupValues[1]
            val field = if (lowerPrompt.contains("temp")) "temperature_k" else if (lowerPrompt.contains("latency")) "ping_ms" else "threshold_value"
            filters.add(QueryFilter(field, "GREATER_THAN", value))
        }

        val ltRegex = Regex("""(?:<|less than|below|under)\s*([0-9.]+)""", RegexOption.IGNORE_CASE)
        val ltMatch = ltRegex.find(lowerPrompt)
        if (ltMatch != null) {
            val value = ltMatch.groupValues[1]
            val field = if (lowerPrompt.contains("stock")) "available_qty" else "metric_val"
            filters.add(QueryFilter(field, "LESS_THAN", value))
        }

        // Role / user filter
        if (lowerPrompt.contains("admin")) {
            filters.add(QueryFilter("user_role", "CONTAINS", "admin"))
        }

        if (filters.isEmpty()) {
            filters.add(QueryFilter("record_status", "EQUALS", "ACTIVE"))
        }

        // 4. Craft explanation
        val explanation = buildExplanation(matchedTables, queryType, filters)

        val rawPlan = QueryPlan(
            userPrompt = userPrompt,
            targetTables = matchedTables,
            queryType = queryType,
            filters = filters,
            explanation = explanation
        )

        return enrichPlan(rawPlan)
    }

    private fun buildExplanation(tables: List<String>, type: QueryType, filters: List<QueryFilter>): String {
        val tablesStr = tables.joinToString(" and ")
        val filterStr = filters.joinToString(", ") { "${it.field} ${it.operator} '${it.value}'" }

        return when (type) {
            QueryType.JOIN -> {
                "Zetaris acts as the federated virtualization layer across $tablesStr. Instead of ingesting or copying full tables across clouds, Zetaris compiles predicate filters ($filterStr) and pushes down scanning operations directly into each database engine. Only the lightweight matching join keys are streamed to the in-memory virtual fabric, achieving cross-cloud zero-data-movement federation."
            }
            QueryType.AGGREGATE -> {
                "Zetaris pushes aggregation kernels directly to $tablesStr remote storage nodes. Local partition pre-aggregations are computed at source (filtering by $filterStr), and only the consolidated intermediate summary vectors are merged in the Zetaris virtualization mesh."
            }
            QueryType.AUDIT -> {
                "Zetaris deploys an immutable non-intrusive query harness across $tablesStr. Security parameters ($filterStr) are parsed into pushdown predicate filters against source object stores (e.g., S3 Parquet columnar reader), evaluating compliance in real-time with zero raw log exfiltration."
            }
            QueryType.SELECT -> {
                "Zetaris builds a virtual federated schema view over $tablesStr. Column projections and predicate filters ($filterStr) execute natively at the remote database, streaming only the requested records to the client application."
            }
        }
    }

    fun enrichPlan(rawPlan: QueryPlan): QueryPlan {
        val sql = generateFederatedSql(rawPlan)
        val bytesSavedKb = (rawPlan.targetTables.size * 28500L) + (rawPlan.filters.size * 4200L)
        val latencyMs = 85L + (rawPlan.targetTables.size * 32L)

        return rawPlan.copy(
            generatedSql = sql,
            estimatedBytesSavedKb = bytesSavedKb,
            executionLatencyMs = latencyMs
        )
    }

    private fun generateFederatedSql(plan: QueryPlan): String {
        val tables = plan.targetTables
        val primaryTable = tables.firstOrNull() ?: "postgres_orders"
        val filterClause = if (plan.filters.isNotEmpty()) {
            "WHERE " + plan.filters.joinToString("\n  AND ") { filter ->
                val op = when (filter.operator.uppercase()) {
                    "EQUALS" -> "="
                    "GREATER_THAN" -> ">"
                    "LESS_THAN" -> "<"
                    "CONTAINS" -> "LIKE"
                    else -> "="
                }
                val valueFormatted = if (op == "LIKE") "'%${filter.value}%'" else if (filter.value.toDoubleOrNull() != null) filter.value else "'${filter.value}'"
                "${filter.field} $op $valueFormatted"
            }
        } else ""

        return when {
            plan.queryType == QueryType.JOIN && tables.size >= 2 -> {
                val t1 = tables[0]
                val t2 = tables[1]
                """
-- [Zetaris Fabric] Cross-Database Zero-ETL Federated Join
SELECT 
    a.id,
    a.identifier_key,
    b.associated_label,
    a.created_at
FROM zetaris_catalog.$t1 AS a
/* Pushdown Join via Zetaris Virtual Fabric Bridge */
INNER JOIN zetaris_catalog.$t2 AS b
    ON a.foreign_ref_id = b.id
$filterClause
/* Predicates pushed to remote physical engines before network transfer */
LIMIT 100;
                """.trimIndent()
            }
            plan.queryType == QueryType.AGGREGATE -> {
                """
-- [Zetaris Fabric] Distributed Pushdown Aggregation
SELECT 
    target_region,
    COUNT(*) AS total_events,
    ROUND(AVG(metric_value), 2) AS avg_metric
FROM zetaris_catalog.$primaryTable
$filterClause
GROUP BY target_region
ORDER BY total_events DESC;
                """.trimIndent()
            }
            plan.queryType == QueryType.AUDIT -> {
                """
-- [Zetaris Fabric] In-Situ Compliance Audit Scan
SELECT 
    audit_timestamp,
    actor_principal,
    action_type,
    resource_arn,
    threat_severity
FROM zetaris_catalog.$primaryTable
$filterClause
ORDER BY audit_timestamp DESC
LIMIT 50;
                """.trimIndent()
            }
            else -> {
                """
-- [Zetaris Fabric] Virtualized Federated Projection
SELECT *
FROM zetaris_catalog.$primaryTable
$filterClause
LIMIT 100;
                """.trimIndent()
            }
        }
    }

    fun simulateExecution(plan: QueryPlan): SimulationResult {
        val nodePushdown = mutableMapOf<String, String>()
        for (table in plan.targetTables) {
            val status = when (table) {
                "snowflake_inventory" -> "Pushdown Optimized: Column Pruning + Warehouse Cache Hit"
                "postgres_orders" -> "Pushdown Optimized: B-Tree Index Scan on (delivery_status)"
                "aws_s3_logs" -> "Pushdown Optimized: S3 Select Parquet Byte-Range Filter"
                "databricks_manifests" -> "Pushdown Optimized: Delta Partition Elimination"
                "starlink_telemetry" -> "Pushdown Stream: Kafka Offset Window Virtual View"
                "enterprise_billing" -> "Pushdown Optimized: Transactional Snapshot Read"
                else -> "Pushdown Filter Applied at Source"
            }
            nodePushdown[table] = status
        }

        val rows = generateSampleVirtualRows(plan)
        val avoidedMb = (plan.targetTables.size * 48.5) + (plan.filters.size * 12.0)
        val transferredKb = 4.2 + (rows.size * 0.45)

        return SimulationResult(
            queryPlan = plan,
            nodePushdownStatus = nodePushdown,
            bytesTransferredKb = transferredKb,
            bytesAvoidedMb = avoidedMb,
            executionTimeMs = plan.executionLatencyMs,
            virtualRows = rows
        )
    }

    private fun generateSampleVirtualRows(plan: QueryPlan): List<Map<String, String>> {
        val list = mutableListOf<Map<String, String>>()
        val isJoin = plan.queryType == QueryType.JOIN
        val isAudit = plan.queryType == QueryType.AUDIT
        val isAggregate = plan.queryType == QueryType.AGGREGATE

        if (isAudit) {
            list.add(mapOf("TIMESTAMP" to "2026-10-28 09:14:02 UTC", "ACTOR" to "svc-mesh-admin", "ACTION" to "S3:GetObjectTagging", "STATUS" to "UNAUTHORIZED", "SEVERITY" to "HIGH"))
            list.add(mapOf("TIMESTAMP" to "2026-10-28 09:16:45 UTC", "ACTOR" to "node-agent-402", "ACTION" to "IAM:AssumeRole", "STATUS" to "UNAUTHORIZED", "SEVERITY" to "CRITICAL"))
            list.add(mapOf("TIMESTAMP" to "2026-10-28 09:19:11 UTC", "ACTOR" to "telemetry-collector", "ACTION" to "KMS:DecryptKey", "STATUS" to "UNAUTHORIZED", "SEVERITY" to "MEDIUM"))
        } else if (isAggregate) {
            list.add(mapOf("REGION" to "Starbase Boca Chica (US-East)", "EVENTS" to "1,492,030", "AVG_THROUGHPUT_MB" to "842.6", "ERROR_RATE" to "0.01%"))
            list.add(mapOf("REGION" to "Vandenberg SLC-4E (US-West)", "EVENTS" to "984,210", "AVG_THROUGHPUT_MB" to "615.1", "ERROR_RATE" to "0.02%"))
            list.add(mapOf("REGION" to "Cape Canaveral LC-39A (US-East)", "EVENTS" to "2,140,880", "AVG_THROUGHPUT_MB" to "920.4", "ERROR_RATE" to "0.00%"))
        } else if (isJoin) {
            list.add(mapOf("ORDER_ID" to "ORD-89211", "SOURCE_DB" to "postgres_orders", "PART_SKU" to "SKU-SLNK-DISH-V4", "INV_DB" to "snowflake_inventory", "STOCK_STATUS" to "RESERVED", "DELIVERY" to "FAILED"))
            list.add(mapOf("ORDER_ID" to "ORD-89245", "SOURCE_DB" to "postgres_orders", "PART_SKU" to "SKU-RAPTOR-IGN-02", "INV_DB" to "snowflake_inventory", "STOCK_STATUS" to "BACKORDERED", "DELIVERY" to "FAILED"))
            list.add(mapOf("ORDER_ID" to "ORD-89290", "SOURCE_DB" to "postgres_orders", "PART_SKU" to "SKU-STARLINK-PWR-MOD", "INV_DB" to "snowflake_inventory", "STOCK_STATUS" to "AVAILABLE", "DELIVERY" to "FAILED"))
        } else {
            list.add(mapOf("RECORD_ID" to "REC-00109", "CATALOG_SOURCE" to (plan.targetTables.firstOrNull() ?: "postgres_orders"), "ENTITY_KEY" to "STARSHIP-SN33-TELEMETRY", "STATUS" to "VERIFIED", "LATENCY" to "14ms"))
            list.add(mapOf("RECORD_ID" to "REC-00114", "CATALOG_SOURCE" to (plan.targetTables.firstOrNull() ?: "postgres_orders"), "ENTITY_KEY" to "STARSHIP-SN34-TELEMETRY", "STATUS" to "VERIFIED", "LATENCY" to "18ms"))
            list.add(mapOf("RECORD_ID" to "REC-00122", "CATALOG_SOURCE" to (plan.targetTables.firstOrNull() ?: "postgres_orders"), "ENTITY_KEY" to "BOOSTER-B12-THRUST-LOG", "STATUS" to "VERIFIED", "LATENCY" to "12ms"))
        }

        return list
    }
}
