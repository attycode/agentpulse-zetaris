package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Zetaris Deep Space Theme Palette
val SpaceBlack = Color(0xFF090D16)
val SpaceDarkBg = Color(0xFF0D1322)
val SpaceCardBg = Color(0xFF141D30)
val SpaceCardElevated = Color(0xFF1C2740)
val SpaceBorder = Color(0xFF263553)

// Brand Accents
val CyanNeon = Color(0xFF00D2FF)
val CyanMuted = Color(0xFF0090B3)
val TealPulse = Color(0xFF00E5A3)
val PurpleOrbit = Color(0xFFA855F7)
val AmberSolar = Color(0xFFF59E0B)
val CrimsonAlert = Color(0xFFEF4444)

// Text & Surfaces
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Query Type Colors
val QueryTypeSelect = Color(0xFF00D2FF)
val QueryTypeJoin = Color(0xFFA855F7)
val QueryTypeAggregate = Color(0xFFF59E0B)
val QueryTypeAudit = Color(0xFF10B981)
