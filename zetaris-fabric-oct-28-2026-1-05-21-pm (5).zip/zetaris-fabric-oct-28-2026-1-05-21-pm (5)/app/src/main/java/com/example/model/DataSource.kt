package com.example.model

data class ColumnDef(
    val name: String,
    val dataType: String,
    val isIndexed: Boolean = false,
    val sampleValue: String
)

data class DataSourceInfo(
    val id: String,
    val name: String,
    val engine: String,
    val iconType: String,
    val cloudRegion: String,
    val estimatedRecords: String,
    val zeroEtlSupported: Boolean = true,
    val pushdownFeatures: List<String>,
    val averagePingMs: Int,
    val status: String = "HEALTHY",
    val description: String,
    val columns: List<ColumnDef>
)
