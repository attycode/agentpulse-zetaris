package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.ZetarisViewModel
import com.example.ui.screens.FabricCatalogScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.QueryPlannerScreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SpaceBlack
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.SpaceDarkBg
import com.example.ui.theme.TealPulse
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: ZetarisViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val savedPlans by viewModel.savedPlans.collectAsStateWithLifecycle()

                // BackHandler returns to Planner if on another tab
                BackHandler(enabled = uiState.selectedTab != 0) {
                    viewModel.setSelectedTab(0)
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = SpaceDarkBg,
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(CyanNeon),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Hub,
                                                contentDescription = null,
                                                tint = SpaceBlack,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "ZETARIS FABRIC",
                                                color = TextPrimary,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Black,
                                                letterSpacing = 1.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "SpaceXSI Federated Query Engine",
                                                color = TealPulse,
                                                fontSize = 10.5.sp,
                                                letterSpacing = 0.5.sp
                                            )
                                        }
                                    }

                                    // Mesh Status Indicator
                                    Row(
                                        modifier = Modifier
                                            .padding(end = 12.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(SpaceCardBg)
                                            .border(1.dp, SpaceBorder, RoundedCornerShape(12.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(TealPulse)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "ONLINE",
                                            color = TealPulse,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.8.sp
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = SpaceDarkBg
                            ),
                            modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = SpaceBlack,
                            contentColor = TextSecondary,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = uiState.selectedTab == 0,
                                onClick = { viewModel.setSelectedTab(0) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Planner"
                                    )
                                },
                                label = { Text("Planner", fontSize = 11.5.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SpaceBlack,
                                    selectedTextColor = CyanNeon,
                                    indicatorColor = CyanNeon,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_planner")
                            )

                            NavigationBarItem(
                                selected = uiState.selectedTab == 1,
                                onClick = { viewModel.setSelectedTab(1) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Storage,
                                        contentDescription = "Data Fabric"
                                    )
                                },
                                label = { Text("Fabric Catalog", fontSize = 11.5.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SpaceBlack,
                                    selectedTextColor = CyanNeon,
                                    indicatorColor = CyanNeon,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_fabric")
                            )

                            NavigationBarItem(
                                selected = uiState.selectedTab == 2,
                                onClick = { viewModel.setSelectedTab(2) },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = "Saved Plans"
                                    )
                                },
                                label = { Text("Saved Plans", fontSize = 11.5.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = SpaceBlack,
                                    selectedTextColor = CyanNeon,
                                    indicatorColor = CyanNeon,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag("nav_history")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.selectedTab) {
                            0 -> QueryPlannerScreen(
                                state = uiState,
                                onPromptChange = viewModel::onPromptChange,
                                onGenerateClick = { viewModel.generatePlan() },
                                onSimulateClick = viewModel::runSimulation,
                                onSavePlanClick = viewModel::saveCurrentPlan,
                                onDismissSimulation = viewModel::dismissSimulation,
                                getJsonRepresentation = viewModel::getPlanJson
                            )
                            1 -> FabricCatalogScreen(
                                dataSources = viewModel.dataSources,
                                onSelectSource = { sourceName ->
                                    viewModel.onPromptChange("Query and analyze records in $sourceName")
                                    viewModel.setSelectedTab(0)
                                }
                            )
                            2 -> HistoryScreen(
                                savedPlans = savedPlans,
                                activeFilter = uiState.historyFilter,
                                onFilterChange = viewModel::setHistoryFilter,
                                onSelectPlan = viewModel::selectSavedPlan,
                                onDeletePlan = viewModel::deleteSavedPlan
                            )
                        }
                    }
                }
            }
        }
    }
}
