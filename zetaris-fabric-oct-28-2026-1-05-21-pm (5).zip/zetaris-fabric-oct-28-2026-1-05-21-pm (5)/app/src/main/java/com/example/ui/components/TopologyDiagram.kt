package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.PurpleOrbit
import com.example.ui.theme.SpaceBlack
import com.example.ui.theme.SpaceBorder
import com.example.ui.theme.SpaceCardBg
import com.example.ui.theme.TealPulse
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TopologyDiagram(
    targetTables: List<String>,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SpaceCardBg)
            .border(1.dp, SpaceBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Hub,
                contentDescription = null,
                tint = CyanNeon,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "ZETARIS DISTRIBUTED TOPOLOGY",
                color = TextPrimary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(TealPulse.copy(alpha = pulseAlpha))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Zero-ETL Mesh",
                color = TealPulse,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Canvas representing the remote databases converging at the Zetaris Fabric Node
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SpaceBlack)
                .border(1.dp, SpaceBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
        ) {
            val width = size.width
            val height = size.height

            // Center: Zetaris Virtual Engine
            val center = Offset(width / 2f, height / 2f)

            // Sources on Left and Right
            val leftNode1 = Offset(width * 0.16f, height * 0.28f)
            val leftNode2 = Offset(width * 0.16f, height * 0.72f)
            val rightNode1 = Offset(width * 0.84f, height * 0.28f)
            val rightNode2 = Offset(width * 0.84f, height * 0.72f)

            val nodes = listOf(leftNode1, leftNode2, rightNode1, rightNode2)

            // Draw glowing dashed connection links
            nodes.forEachIndexed { index, nodePos ->
                val linkColor = if (index % 2 == 0) CyanNeon else TealPulse
                drawLine(
                    color = linkColor.copy(alpha = 0.45f),
                    start = nodePos,
                    end = center,
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), pulseAlpha * 20f)
                )

                // Remote node circle
                drawCircle(
                    color = SpaceBorder,
                    radius = 16.dp.toPx(),
                    center = nodePos
                )
                drawCircle(
                    color = linkColor.copy(alpha = 0.25f),
                    radius = 12.dp.toPx(),
                    center = nodePos
                )
                drawCircle(
                    color = linkColor,
                    radius = 4.dp.toPx(),
                    center = nodePos
                )
            }

            // Draw central Zetaris node
            drawCircle(
                color = PurpleOrbit.copy(alpha = 0.25f * pulseAlpha),
                radius = 28.dp.toPx(),
                center = center
            )
            drawCircle(
                color = SpaceBorder,
                radius = 20.dp.toPx(),
                center = center
            )
            drawCircle(
                color = CyanNeon.copy(alpha = 0.3f),
                radius = 14.dp.toPx(),
                center = center
            )
            drawCircle(
                color = CyanNeon,
                radius = 6.dp.toPx(),
                center = center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Federating: ${targetTables.joinToString("  •  ")}",
                color = TextSecondary,
                fontSize = 11.5.sp,
                maxLines = 1
            )
        }
    }
}
