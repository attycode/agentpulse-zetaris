package com.example.model

enum class QueryType {
    SELECT,
    AGGREGATE,
    JOIN,
    AUDIT
}

data class QueryFilter(
    val field: String,
    val operator: String,
    val value: String
)

data class QueryPlan(
    val id: String = java.util.UUID.randomUUID().toString(),
    val userPrompt: String = "",
    val targetTables: List<String> = emptyList(),
    val queryType: QueryType = QueryType.SELECT,
    val filters: List<QueryFilter> = emptyList(),
    val explanation: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val generatedSql: String = "",
    val estimatedBytesSavedKb: Long = 0,
    val executionLatencyMs: Long = 0
)

data class SimulationResult(
    val queryPlan: QueryPlan,
    val nodePushdownStatus: Map<String, String>,
    val bytesTransferredKb: Double,
    val bytesAvoidedMb: Double,
    val executionTimeMs: Long,
    val virtualRows: List<Map<String, String>>
)
