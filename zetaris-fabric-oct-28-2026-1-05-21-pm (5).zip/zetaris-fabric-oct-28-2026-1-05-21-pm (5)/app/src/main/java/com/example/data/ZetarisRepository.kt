package com.example.data

import com.example.BuildConfig
import com.example.data.remote.FallbackSemanticEngine
import com.example.data.remote.GeminiService
import com.example.model.ColumnDef
import com.example.model.DataSourceInfo
import com.example.model.QueryPlan
import com.example.model.SimulationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ZetarisRepository {

    private val geminiService = GeminiService(
        apiKey = BuildConfig.GEMINI_API_KEY
    )

    private val _savedPlans = MutableStateFlow<List<QueryPlan>>(emptyList())
    val savedPlans: StateFlow<List<QueryPlan>> = _savedPlans.asStateFlow()

    init {
        // Pre-populate with initial SpaceXSI mission query plans
        val initialPrompt1 = "Find all failed starlink deliveries in postgres_orders joined with snowflake_inventory"
        val initialPlan1 = FallbackSemanticEngine.parse(initialPrompt1)

        val initialPrompt2 = "Audit access logs in aws_s3_logs for unauthorized admin operations"
        val initialPlan2 = FallbackSemanticEngine.parse(initialPrompt2)

        _savedPlans.value = listOf(initialPlan1, initialPlan2)
    }

    suspend fun parseNaturalLanguageQuery(userPrompt: String): QueryPlan {
        return geminiService.parseNaturalLanguageQuery(userPrompt)
    }

    fun saveQueryPlan(plan: QueryPlan) {
        val current = _savedPlans.value.toMutableList()
        val existingIndex = current.indexOfFirst { it.id == plan.id }
        if (existingIndex >= 0) {
            current[existingIndex] = plan
        } else {
            current.add(0, plan)
        }
        _savedPlans.value = current
    }

    fun deleteQueryPlan(planId: String) {
        _savedPlans.value = _savedPlans.value.filterNot { it.id == planId }
    }

    fun simulateExecution(plan: QueryPlan): SimulationResult {
        return FallbackSemanticEngine.simulateExecution(plan)
    }

    fun getFabricDataSources(): List<DataSourceInfo> {
        return listOf(
            DataSourceInfo(
                id = "snowflake_inventory",
                name = "snowflake_inventory",
                engine = "Snowflake Data Cloud",
                iconType = "snowflake",
                cloudRegion = "AWS us-east-1 (N. Virginia)",
                estimatedRecords = "14,820,000 rows",
                pushdownFeatures = listOf("Micro-partition Pruning", "Columnar Scan Pushdown", "Subquery Projection"),
                averagePingMs = 38,
                description = "Central aerospace component warehouse catalog, stock replenishment thresholds, part serial numbers, and vendor inventory.",
                columns = listOf(
                    ColumnDef("sku", "VARCHAR(64)", isIndexed = true, sampleValue = "SKU-SLNK-DISH-V4"),
                    ColumnDef("part_name", "VARCHAR(256)", isIndexed = false, sampleValue = "Starlink Phased Array Receiver v4"),
                    ColumnDef("warehouse_stock", "INTEGER", isIndexed = false, sampleValue = "1840"),
                    ColumnDef("supplier_code", "VARCHAR(32)", isIndexed = true, sampleValue = "VND-NORTHROP-01"),
                    ColumnDef("unit_cost_usd", "DECIMAL(12,2)", isIndexed = false, sampleValue = "499.00")
                )
            ),
            DataSourceInfo(
                id = "postgres_orders",
                name = "postgres_orders",
                engine = "PostgreSQL Enterprise (AWS RDS)",
                iconType = "postgres",
                cloudRegion = "AWS eu-central-1 (Frankfurt)",
                estimatedRecords = "2,350,000 rows",
                pushdownFeatures = listOf("B-Tree Index Pushdown", "Predicate Filter Pushdown", "Limit/Offset Pushdown"),
                averagePingMs = 82,
                description = "Global high-speed customer order stream, orbital launch bookings, fulfillment status, and delivery coordinates.",
                columns = listOf(
                    ColumnDef("order_id", "UUID", isIndexed = true, sampleValue = "d94b-482a-bc91"),
                    ColumnDef("customer_id", "VARCHAR(64)", isIndexed = true, sampleValue = "CUST-ORBITAL-99"),
                    ColumnDef("delivery_status", "VARCHAR(32)", isIndexed = true, sampleValue = "FAILED"),
                    ColumnDef("part_id", "VARCHAR(64)", isIndexed = true, sampleValue = "SKU-SLNK-DISH-V4"),
                    ColumnDef("ordered_at", "TIMESTAMP", isIndexed = false, sampleValue = "2026-10-28 07:12:00")
                )
            ),
            DataSourceInfo(
                id = "aws_s3_logs",
                name = "aws_s3_logs",
                engine = "Amazon S3 Parquet Lake",
                iconType = "s3",
                cloudRegion = "AWS us-west-2 (Oregon)",
                estimatedRecords = "185,400,000 events",
                pushdownFeatures = listOf("S3 Select Column Pushdown", "Parquet Byte-Range Filtering", "Partition Elimination"),
                averagePingMs = 45,
                description = "High-velocity infrastructure audit trails, IAM security telemetry, mesh proxy logs, and access control audit records.",
                columns = listOf(
                    ColumnDef("audit_timestamp", "TIMESTAMP", isIndexed = true, sampleValue = "2026-10-28 09:14:02"),
                    ColumnDef("actor_principal", "VARCHAR(128)", isIndexed = true, sampleValue = "svc-mesh-admin"),
                    ColumnDef("action_type", "VARCHAR(64)", isIndexed = false, sampleValue = "S3:GetObjectTagging"),
                    ColumnDef("action_status", "VARCHAR(32)", isIndexed = true, sampleValue = "UNAUTHORIZED"),
                    ColumnDef("threat_severity", "VARCHAR(16)", isIndexed = false, sampleValue = "HIGH")
                )
            ),
            DataSourceInfo(
                id = "databricks_manifests",
                name = "databricks_manifests",
                engine = "Databricks Delta Lake",
                iconType = "databricks",
                cloudRegion = "GCP us-central1 (Iowa)",
                estimatedRecords = "850,000 manifests",
                pushdownFeatures = listOf("Delta Log Z-Ordering", "Min/Max Stats Pruning", "Vectorized Reader"),
                averagePingMs = 29,
                description = "Starship and Falcon 9 launch manifests, payload fairing configurations, orbital trajectory targets, and pre-launch checkpoints.",
                columns = listOf(
                    ColumnDef("manifest_id", "VARCHAR(64)", isIndexed = true, sampleValue = "MNF-STARSHIP-IFT-7"),
                    ColumnDef("mission_name", "VARCHAR(128)", isIndexed = false, sampleValue = "Starlink Group 12-4"),
                    ColumnDef("launch_vehicle", "VARCHAR(64)", isIndexed = false, sampleValue = "Starship Full Stack SN33/B12"),
                    ColumnDef("status", "VARCHAR(32)", isIndexed = true, sampleValue = "PENDING"),
                    ColumnDef("payload_mass_kg", "FLOAT", isIndexed = false, sampleValue = "125000.0")
                )
            ),
            DataSourceInfo(
                id = "starlink_telemetry",
                name = "starlink_telemetry",
                engine = "Kafka & TimescaleDB Stream",
                iconType = "kafka",
                cloudRegion = "Distributed Edge Mesh",
                estimatedRecords = "5,200,000 events/sec",
                pushdownFeatures = listOf("Continuous Aggregate Pushdown", "Hypertable Chunk Pruning", "Window Filter"),
                averagePingMs = 19,
                description = "Real-time laser inter-satellite link metrics, gateway ground station latency, phased-array temperature readings, and beam steering telemetry.",
                columns = listOf(
                    ColumnDef("satellite_id", "VARCHAR(32)", isIndexed = true, sampleValue = "STARLINK-4890"),
                    ColumnDef("temperature_k", "FLOAT", isIndexed = false, sampleValue = "1245.8"),
                    ColumnDef("ping_ms", "INTEGER", isIndexed = false, sampleValue = "14"),
                    ColumnDef("beam_frequency_ghz", "FLOAT", isIndexed = false, sampleValue = "14.25"),
                    ColumnDef("is_active", "BOOLEAN", isIndexed = true, sampleValue = "TRUE")
                )
            ),
            DataSourceInfo(
                id = "enterprise_billing",
                name = "enterprise_billing",
                engine = "Oracle Cloud ERP Financials",
                iconType = "oracle",
                cloudRegion = "OCI ap-northeast-1 (Tokyo)",
                estimatedRecords = "920,000 ledger rows",
                pushdownFeatures = listOf("ACID Consistent Snapshot Read", "Predicate Pushdown", "Partition Filter"),
                averagePingMs = 110,
                description = "Enterprise spaceflight contracts, government launch procurement accounts, commercial satellite bandwidth invoices, and billing reconciliation.",
                columns = listOf(
                    ColumnDef("invoice_number", "VARCHAR(64)", isIndexed = true, sampleValue = "INV-2026-USAF-08"),
                    ColumnDef("account_name", "VARCHAR(128)", isIndexed = true, sampleValue = "Space Development Agency"),
                    ColumnDef("amount_usd", "DECIMAL(14,2)", isIndexed = false, sampleValue = "14500000.00"),
                    ColumnDef("payment_status", "VARCHAR(32)", isIndexed = true, sampleValue = "PAID"),
                    ColumnDef("due_date", "DATE", isIndexed = false, sampleValue = "2026-11-15")
                )
            )
        )
    }
}
