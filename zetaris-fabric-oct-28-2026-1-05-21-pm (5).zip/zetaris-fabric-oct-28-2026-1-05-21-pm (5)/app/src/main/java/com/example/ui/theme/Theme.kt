package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val ZetarisDarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = SpaceBlack,
    primaryContainer = SpaceCardElevated,
    onPrimaryContainer = CyanNeon,
    secondary = TealPulse,
    onSecondary = SpaceBlack,
    secondaryContainer = SpaceCardBg,
    onSecondaryContainer = TealPulse,
    tertiary = PurpleOrbit,
    onTertiary = SpaceBlack,
    background = SpaceDarkBg,
    onBackground = TextPrimary,
    surface = SpaceCardBg,
    onSurface = TextPrimary,
    surfaceVariant = SpaceCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = SpaceBorder,
    error = CrimsonAlert,
    onError = SpaceBlack
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = ZetarisDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
