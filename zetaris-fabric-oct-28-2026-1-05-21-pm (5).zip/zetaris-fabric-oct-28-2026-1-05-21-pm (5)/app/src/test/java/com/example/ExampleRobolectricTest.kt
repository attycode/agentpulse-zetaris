package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.FallbackSemanticEngine
import com.example.model.QueryType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Zetaris Fabric", appName)
  }

  @Test
  fun `verify federated query planning for joined tables`() {
    val prompt = "Find all failed starlink deliveries in postgres_orders joined with snowflake_inventory"
    val plan = FallbackSemanticEngine.parse(prompt)

    assertEquals(QueryType.JOIN, plan.queryType)
    assertTrue(plan.targetTables.contains("postgres_orders"))
    assertTrue(plan.targetTables.contains("snowflake_inventory"))
    assertTrue(plan.filters.any { it.field == "delivery_status" && it.value == "FAILED" })
    assertTrue(plan.generatedSql.contains("Zetaris Fabric"))
    assertTrue(plan.explanation.isNotBlank())
  }

  @Test
  fun `verify zero ETL simulation results`() {
    val prompt = "Audit access logs in aws_s3_logs for unauthorized admin operations"
    val plan = FallbackSemanticEngine.parse(prompt)
    val simulation = FallbackSemanticEngine.simulateExecution(plan)

    assertNotNull(simulation)
    assertTrue(simulation.bytesAvoidedMb > 0)
    assertTrue(simulation.virtualRows.isNotEmpty())
    assertTrue(simulation.nodePushdownStatus.containsKey("aws_s3_logs"))
  }
}
